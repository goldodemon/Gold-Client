package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.MouseSimulation;
import dlindustries.vigillant.system.utils.TimerUtils;
import dlindustries.vigillant.system.utils.WorldUtils;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public final class TriggerBot extends Module implements TickListener, AttackListener {
    public enum Mode {
        MACE("Mace"),
        WEAPONS("Weapons"),
        MACE_AND_WEAPONS("Mace and Weapons"),
        ALL_ITEMS("All Items");
        private final String name;
        Mode(String name) {
            this.name = name;
        }
        @Override
        public String toString() {
            return name;
        }
    }
    private final ModeSetting<Mode> mode = new ModeSetting<>(EncryptedString.of("Mode"), Mode.WEAPONS, Mode.class);
    private final BooleanSetting inScreen = new BooleanSetting(EncryptedString.of("Work In Screen"), false)
            .setDescription(EncryptedString.of("Will trigger even if youre inside a screen"));
    private final BooleanSetting whileUse = new BooleanSetting(EncryptedString.of("While Use"), false)
            .setDescription(EncryptedString.of("Will hit the player no matter if you're eating or blocking with a shield"));
    private final BooleanSetting onLeftClick = new BooleanSetting(EncryptedString.of("On Left Click"), false)
            .setDescription(EncryptedString.of("Only gets triggered if holding down left click"));
    private final MinMaxSetting swordDelay = new MinMaxSetting(EncryptedString.of("Sword Delay"), 0, 1000, 1, 540, 550)
            .setDescription(EncryptedString.of("Delay for swords"));
    private final MinMaxSetting axeDelay = new MinMaxSetting(EncryptedString.of("Axe Delay"), 0, 1000, 1, 780, 800)
            .setDescription(EncryptedString.of("Delay for axes"));
    private final BooleanSetting checkShield = new BooleanSetting(EncryptedString.of("Check Shield"), false)
            .setDescription(EncryptedString.of("Checks if the player is blocking your hits with a shield (Recommended with Shield Disabler)"));
    private final BooleanSetting onlyCritSword = new BooleanSetting(EncryptedString.of("Only Crit Sword"), false)
            .setDescription(EncryptedString.of("Only does critical hits with a sword"));
    private final BooleanSetting onlyCritAxe = new BooleanSetting(EncryptedString.of("Only Crit Axe"), false)
            .setDescription(EncryptedString.of("Only does critical hits with an axe"));
    private final BooleanSetting swing = new BooleanSetting(EncryptedString.of("Swing Hand"), true)
            .setDescription(EncryptedString.of("Whether to swing the hand or not"));
    private final BooleanSetting whileAscend = new BooleanSetting(EncryptedString.of("While Ascending"), false)
            .setDescription(EncryptedString.of("Wont hit if you're ascending from a jump, only if on ground or falling"));
    private final BooleanSetting clickSimulation = new BooleanSetting(EncryptedString.of("Click Simulation"), true)
            .setDescription(EncryptedString.of("Makes the CPS hud think you're legit"));
    private final BooleanSetting strayBypass = new BooleanSetting(EncryptedString.of("bypass mode"), true)
            .setDescription(EncryptedString.of("Bypasses stray's Anti-TriggerBot and other strict anticheats"));
    private final BooleanSetting allEntities = new BooleanSetting(EncryptedString.of("All Entities"), false)
            .setDescription(EncryptedString.of("Will attack all entities"));
    private final BooleanSetting sticky = new BooleanSetting(EncryptedString.of("Same Player"), false)
            .setDescription(EncryptedString.of("Hits the player that was recently attacked, good for FFAs"));
    private final TimerUtils timer = new TimerUtils();
    private int currentSwordDelay, currentAxeDelay;
    private boolean isMaceAttack = false;
    public TriggerBot() {
        super(EncryptedString.of("Trigger Bot"),
                EncryptedString.of("Automatically hits players for you"),
                -1,
                Category.sword);
        addSettings(mode, inScreen, whileUse, onLeftClick, swordDelay, axeDelay, checkShield,
                whileAscend, sticky, onlyCritSword, onlyCritAxe, swing, clickSimulation,
                strayBypass, allEntities);
    }
    @Override
    public void onEnable() {
        currentSwordDelay = swordDelay.getRandomValueInt();
        currentAxeDelay = axeDelay.getRandomValueInt();

        eventManager.add(TickListener.class, this);
        eventManager.add(AttackListener.class, this);
        super.onEnable();
    }
    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        eventManager.remove(AttackListener.class, this);
        super.onDisable();
    }
    @SuppressWarnings("all")
    @Override
    public void onTick() {
        try {
            if (!inScreen.getValue() && mc.currentScreen != null)
                return;
            Item item = mc.player.getMainHandStack().getItem();
            if (!isItemAllowed(item)) {
                return;
            }
            if (onLeftClick.getValue() && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
                return;
            if (((mc.player.getOffHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD) ||
                    mc.player.getOffHandStack().getItem() instanceof ShieldItem) &&
                    GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) &&
                    !whileUse.getValue())
                return;
            if (!whileAscend.getValue() && ((!mc.player.isOnGround() && mc.player.getVelocity().y > 0) ||
                    (!mc.player.isOnGround() && mc.player.fallDistance <= 0.0F)))
                return;
            if (item instanceof MaceItem) {
                handleMaceMode();
            } else if (isSword(item)) {
                handleSwordMode();
            } else if (item instanceof AxeItem) {
                handleAxeMode();
            } else {
                handleAllItemsMode();
            }
        } catch (Exception ignored) {}
    }

    private boolean isItemAllowed(Item item) {
        Mode currentMode = mode.getMode();

        if (currentMode == Mode.MACE) {
            return item instanceof MaceItem;
        }
        else if (currentMode == Mode.WEAPONS) {
            return isSword(item) || item instanceof AxeItem;
        }
        else if (currentMode == Mode.MACE_AND_WEAPONS) {
            return item instanceof MaceItem || isSword(item) || item instanceof AxeItem;
        }
        return true;
    }
    private boolean isSword(Item item) {
        return new ItemStack(item).isIn(ItemTags.SWORDS);
    }
    private void handleMaceMode() {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            Entity entity = hit.getEntity();
            if (!isValidEntity(entity)) return;
            if (entity instanceof PlayerEntity player) {
                if (checkShield.getValue() && player.isBlocking() && !WorldUtils.isShieldFacingAway(player))
                    return;
            }
            if (onlyCritSword.getValue() && mc.player.fallDistance <= 0.0F)
                return;
            isMaceAttack = true;
            WorldUtils.hitEntity(entity, swing.getValue());
            if (clickSimulation.getValue()) {
                MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);
            }
            isMaceAttack = false;
        }
    }
    private void handleSwordMode() {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            Entity entity = hit.getEntity();
            assert mc.player.getAttacking() != null;
            if (sticky.getValue() && entity != mc.player.getAttacking())
                return;
            if (!isValidEntity(entity))
                return;
            if (entity instanceof PlayerEntity player) {
                if (checkShield.getValue() && player.isBlocking() && !WorldUtils.isShieldFacingAway(player))
                    return;
            }
            if (onlyCritSword.getValue() && mc.player.fallDistance <= 0.0F)
                return;
            if (timer.delay(currentSwordDelay)) {
                WorldUtils.hitEntity(entity, swing.getValue());

                if (clickSimulation.getValue())
                    MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

                currentSwordDelay = swordDelay.getRandomValueInt();
                timer.reset();
            }
        }
    }
    private void handleAxeMode() {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            Entity entity = hit.getEntity();
            if (!isValidEntity(entity))
                return;
            if (entity instanceof PlayerEntity player) {
                if (checkShield.getValue() && player.isBlocking() && !WorldUtils.isShieldFacingAway(player))
                    return;
            }
            if (onlyCritAxe.getValue() && mc.player.fallDistance <= 0.0F)
                return;
            if (timer.delay(currentAxeDelay)) {
                WorldUtils.hitEntity(entity, swing.getValue());
                if (clickSimulation.getValue())
                    MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);
                currentAxeDelay = axeDelay.getRandomValueInt();
                timer.reset();
            }
        }
    }
    private void handleAllItemsMode() {
        if (mc.crosshairTarget instanceof EntityHitResult entityHit && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity entity = entityHit.getEntity();
            assert mc.player.getAttacking() != null;
            if (sticky.getValue() && entity != mc.player.getAttacking())
                return;
            if (!isValidEntity(entity))
                return;
            if (entity instanceof PlayerEntity player) {
                if (checkShield.getValue() && player.isBlocking() && !WorldUtils.isShieldFacingAway(player))
                    return;
            }
            if (onlyCritSword.getValue() && mc.player.fallDistance <= 0.0F)
                return;
            if (timer.delay(currentSwordDelay)) {
                WorldUtils.hitEntity(entity, swing.getValue());
                if (clickSimulation.getValue())
                    MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);
                currentSwordDelay = swordDelay.getRandomValueInt();
                timer.reset();
            }
        }
    }
    private boolean isValidEntity(Entity entity) {
        return entity instanceof LivingEntity && entity.isAlive();
    }
    @Override
    public void onAttack(AttackEvent event) {
        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
            event.cancel();
    }
    public boolean isMaceAttackActive() {
        return isMaceAttack;
    }
}